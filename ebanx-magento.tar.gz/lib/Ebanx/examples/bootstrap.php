<?php

require_once __DIR__ . '/../vendor/autoload.php';

\Ebanx\Config::set(array(
  'integrationKey' => '',
  'directMode'     => false,
  'testMode'       => true
));
