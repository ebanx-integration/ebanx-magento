<?php

require_once basename(__DIR__) . '/../vendor/autoload.php';
require_once 'TestCase.php';