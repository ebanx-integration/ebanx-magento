<?php

class Ebanx_Ebanx_Helper_Data extends Mage_Payment_Helper_Data
{
}